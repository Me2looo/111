from utils.query import query
import re
import sys
import pandas as pd
sys.path.append('model')

def getAllCommentsData():
    commentList = query('select * from comments',[],'select')
    return commentList

def getAllArticleData():
    articleList = query('select * from article',[],'select')
    return articleList

def getAllHotWords():
    data = []
    df = pd.read_csv('./model/cipinTotal.csv',encoding='utf-8')
    for i in df.values:
        try:
            data.append([
                re.search('[\u4e00-\u9fa5]+',str(i)).group(),#提取中文词语
                re.search('\d+',str(i)).group()#提取第一个出现的数字
            ])
        except:
            continue
    return data
