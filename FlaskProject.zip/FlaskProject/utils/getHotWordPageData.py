from utils.getPublicData import *

def getHotWordLen(hotWord):
    commentsList = getAllCommentsData()
    hotWordLen = 0
    for i in commentsList:
        if i[4].find(hotWord) != -1:
            hotWordLen += 1
    return hotWordLen

def getHotWordPageCreateAtCharData(hotWord):
    commentsList = getAllCommentsData()
    createAt = {}
    for i in commentsList:
        if i[4].find(hotWord) != -1:
            if createAt.get(i[1],-1) == -1:
                createAt[i[1]] = 1
            else:
                createAt[i[1]] = createAt[i[1]] + 1
    return list(createAt.keys()),list(createAt.values())

def getCommentFilterData(hotWord):
    commentsList = getAllCommentsData()
    commentData = []
    for i in commentsList:
        if i[4].find(hotWord) != -1:
            commentData.append(i)
    return commentData

