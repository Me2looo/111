import requests
import csv
import numpy as np
import os

def init():
    if not os.path.exists('./navData.csv'):
        with open('./navData.csv', 'w', encoding='utf-8',newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow([
                'typeName',
                'gid',
                'containerid'
            ])

def writerRow(row):
    with open('./navData.csv', 'a', encoding='utf-8', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(row)

def get_data(url):
    headers = {
        'Cookie': 'WBPSESS=Dt2hbAUaXfkVprjyrAZT_BaCky_mguhGNcgB7QrX2CuNy0TGq3Xax0zZzUDJ5dRBApNHNZwiHoIaqswezfVjfsJrOVNjedEGTbVw-hxO1irf1j0EGiv9r3qB4orqCCTiU5S4TbEV2OfGMJDc4_Py3sGyRP9KSbya5uiAClntFu96fZar15ZUV8SYczvCyyJes616eCBa3QJjmMKOKKn4gA==; ALF=02_1749447635; SUB=_2A25FGpaDDeRhGeFM7FIZ8y7KzDuIHXVmWZZLrDV8PUNbmtANLUPtkW9NQKi6aiVS91Br-3qvZ-o0yf5jWL6u3YaI; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WF2iemXuLwl.8LPjBiTDpNg5NHD95QNeoM71he7SoMNWs4DqcjTS8LydcUjIPxX9Pzt; XSRF-TOKEN=vlLmq_u3GuFlTtFY61CZOtEU; SCF=ArJOEtUHtvLHNxd3qz41gvgbFi9ciVVx8N4HCQv8FXzv_HReJW-x3Xi2GUvhw3J8o9N3vsLOEkxz5rF05eKxOUw.',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.1.15'
    }
    params={
        'is_new_segment': 1,
        'fetch_hot': 1
    }
    response = requests.get(url,headers=headers,params=params)
    if response.status_code == 200:
        return response.json()
    else :
        return None

def parse_json(response):
    navList = np.append(response['groups'][3]['group'],response['groups'][4]['group'])
    for nav in navList:
        navName = nav['title']
        gid = nav['gid']
        containerid = nav['containerid']
        writerRow([
            navName,
            gid,
            containerid
        ])

if __name__ == '__main__':
    init()
    url = 'https://weibo.com/ajax/feed/allGroups'
    response = get_data(url)
    parse_json(response)