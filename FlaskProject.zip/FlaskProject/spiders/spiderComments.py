import time
import csv
from logging import exception

import requests
import os
from datetime import datetime

def init():
    if not os.path.exists('./articleComments.csv'):
        with open('./articleComments.csv', 'w', encoding='utf-8',newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow([
                'articleid',
                'created_at',
                'likes_counts',
                'region',
                'content',
                'authorName',
                'authorGender',
                'authorAddress',
                'authorAvatar'
            ])

def writerRow(row):
    with open('./articleComments.csv', 'a', encoding='utf-8', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(row)

def get_data(url,params):
    headers = {
        'Cookie': 'WBPSESS=Dt2hbAUaXfkVprjyrAZT_BaCky_mguhGNcgB7QrX2CuNy0TGq3Xax0zZzUDJ5dRBApNHNZwiHoIaqswezfVjfsJrOVNjedEGTbVw-hxO1irf1j0EGiv9r3qB4orqCCTiU5S4TbEV2OfGMJDc4_Py3sGyRP9KSbya5uiAClntFu96fZar15ZUV8SYczvCyyJes616eCBa3QJjmMKOKKn4gA==; ALF=02_1749447635; SUB=_2A25FGpaDDeRhGeFM7FIZ8y7KzDuIHXVmWZZLrDV8PUNbmtANLUPtkW9NQKi6aiVS91Br-3qvZ-o0yf5jWL6u3YaI; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WF2iemXuLwl.8LPjBiTDpNg5NHD95QNeoM71he7SoMNWs4DqcjTS8LydcUjIPxX9Pzt; XSRF-TOKEN=vlLmq_u3GuFlTtFY61CZOtEU; SCF=ArJOEtUHtvLHNxd3qz41gvgbFi9ciVVx8N4HCQv8FXzv_HReJW-x3Xi2GUvhw3J8o9N3vsLOEkxz5rF05eKxOUw.',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.1.15'
    }
    response = requests.get(url,headers=headers,params=params)
    if response.status_code == 200:
        return response.json()['data']
    else :
        return None

def parse_json(response,articleId):
    for comment in response:
        created_at = datetime.strptime(comment['created_at'],'%a %b %d %H:%M:%S %z %Y').strftime('%Y-%m-%d')
        likes_counts = comment['like_counts']
        try:
            region = comment['source']
        except:
            region = '未知'
        content = comment['text_raw']
        authorName = comment['user'][ 'screen_name']
        authorGender = comment['user']['gender']
        try:
            authorAddress = comment['source'].replace('来自','')
        except:
            authorAddress = '未知'
        authorAvatar = comment['user']['avatar_large']
        writerRow([
            articleId,
            created_at,
            likes_counts,
            region,
            content,
            authorName,
            authorGender,
            authorAddress,
            authorAvatar
        ])


def getAllArticleList():
    articleList = []
    with open('./articleData.csv','r',encoding='utf-8') as reader:
        readerCsv = csv.reader(reader)
        next(reader)
        for nav in readerCsv:
            articleList.append(nav)
    return articleList

def start(typeNum=3,pageNum=2):
    commentUrl='https://weibo.com/ajax/statuses/buildComments'
    init()
    articleList=getAllArticleList()
    for article in articleList:
        articleId = article[0]
        print('正在爬取文章id值为%s的评论' %articleId)
        time.sleep(3)
        articleId = article[0]
        params = {
            'id':int(articleId),
            'is_show_bulletin':2
        }
        response=get_data(commentUrl,params)
        parse_json(response,articleId)


if __name__ == '__main__':
    start()