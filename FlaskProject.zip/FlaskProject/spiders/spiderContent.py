import time
import csv
from logging import exception

import requests
import os
from datetime import datetime

def init():
    if not os.path.exists('./articleData.csv'):
        with open('./articleData.csv', 'w', encoding='utf-8',newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow([
                'id',
                'likeNum', #点赞的数量
                'commentsLen',
                'reposts_count',
                'region',#地区
                'content',
                'contentLen',
                'created_at',
                'type',
                'detailUrl',
                'authorAvatar',
                'authorName',
                'authorDetail',
                'isVip'
            ])

def writerRow(row):
    with open('./articleData.csv', 'a', encoding='utf-8', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(row)

def get_data(url,params):
    headers = {
        'Cookie': 'WBPSESS=Dt2hbAUaXfkVprjyrAZT_BaCky_mguhGNcgB7QrX2CuNy0TGq3Xax0zZzUDJ5dRBApNHNZwiHoIaqswezfVjfsJrOVNjedEGTbVw-hxO1irf1j0EGiv9r3qB4orqCCTiU5S4TbEV2OfGMJDc4_Py3sGyRP9KSbya5uiAClntFu96fZar15ZUV8SYczvCyyJes616eCBa3QJjmMKOKKn4gA==; ALF=02_1749447635; SUB=_2A25FGpaDDeRhGeFM7FIZ8y7KzDuIHXVmWZZLrDV8PUNbmtANLUPtkW9NQKi6aiVS91Br-3qvZ-o0yf5jWL6u3YaI; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WF2iemXuLwl.8LPjBiTDpNg5NHD95QNeoM71he7SoMNWs4DqcjTS8LydcUjIPxX9Pzt; XSRF-TOKEN=vlLmq_u3GuFlTtFY61CZOtEU; SCF=ArJOEtUHtvLHNxd3qz41gvgbFi9ciVVx8N4HCQv8FXzv_HReJW-x3Xi2GUvhw3J8o9N3vsLOEkxz5rF05eKxOUw.',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.1.15'
    }
    response = requests.get(url,headers=headers,params=params)
    if response.status_code == 200:
        return response.json()['statuses']
    else :
        return None

def parse_json(response,type):
    for article in response:
        id = article['id']
        likeNum = article['attitudes_count']
        commentsLen = article['comments_count']
        reposts_count = article['reposts_count']
        try:
            region = article['region_name'].replace('发布于','')
        except:
            region = '无'
        content = article['text_raw']
        try:
            contentLen = article['textLength']
        except:
            contentLen = '未知'
        created_at = datetime.strptime(article['created_at'],'%a %b %d %H:%M:%S %z %Y').strftime('%Y-%m-%d') #created_at: "Tue Apr 22 15:39:33 +0800 2025"#
        type = type
        try:
            detailUrl = 'https://weibo.com/'+str(article['user']['id'])+'/'+str(article['mblogid']) #instance:https://weibo.com/5469897178/PoVHq01Tp?pagetype=hot,user['id]+article['mblogid'],可能有可能没有
        except:
            detailUrl = '无'
        authorAvatar = article['user']['avatar_large']
        authorName = article['user']['screen_name']
        authorDetail = 'https://weibo.com/u/'+str(article['user']['id']) #用户详情页，instance：https://weibo.com/u/5469897178
        isVip = article['user']['v_plus']
        writerRow([
            id,
            likeNum,  # 点赞的数量
            commentsLen,
            reposts_count,
            region,  # 地区
            content,
            contentLen,
            created_at,
            type,
            detailUrl,
            authorAvatar,
            authorName,
            authorDetail,
            isVip
        ]
        )


def getAllTypeList():
    typeList = []
    with open('./navData.csv','r',encoding='utf-8') as reader:
        readerCsv = csv.reader(reader)
        next(reader)
        for nav in readerCsv:
            typeList.append(nav)
    return typeList

def start(typeNum=3,pageNum=2):
    articleUrl='https://weibo.com/ajax/feed/hottimeline'
    init()
    typeList = getAllTypeList()
    typeNumCount = 0
    for type in typeList:
        if typeNumCount > typeNum:return
        time.sleep(4)
        for page in range(0,pageNum):
            print('正在爬取的类型：%s 中的第%s页文章数据' %(type[0],page+1))
            time.sleep(3)
            params = {
                'group_id':type[1],
                'containerid':type[2],
                'max_id':page,
                'count':10,
                'extparam':'discover|new_feed'
            }
            response = get_data(articleUrl,params)
            parse_json(response,type[0])
        typeNumCount += 1



if __name__ == '__main__':
    start()