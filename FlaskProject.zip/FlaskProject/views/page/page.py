from flask import Flask,session,render_template,redirect,Blueprint,request
from snownlp import SnowNLP
from utils.getHomePageData import *
from utils.getPublicData import getAllHotWords
from utils.getHotWordPageData import *
from utils.getTableData import *

pb = Blueprint('page',__name__,url_prefix='/page',template_folder='templates')
@pb.route('/home')
def home():
    username = session.get('username')
    articleLenMax, likeCountMax, likeCountMaxAuthorName, cityMax = getHomeTagsData()
    commentsLikeCountTopFour = getHomeCommentsLikeCountTopFour()
    xData,yData = getHomeArticleCreateAt()
    typeChart = getHomeTypeChart()
    createAtChart = getHomeCommentCreateChart()
    return render_template('index.html',
                           username=username,
                           articleLenMax=articleLenMax,
                           likeCountMaxAuthorName=likeCountMaxAuthorName,
                           cityMax=cityMax,
                           commentsLikeCountTopFour=commentsLikeCountTopFour,
                           xData=xData,
                           yData=yData,
                           typeChart=typeChart,
                           createAtChart=createAtChart,
                           )
@pb.route('/hotWord')
def hotWord():
    username = session.get('username')
    hotWordList = getAllHotWords()
    defaultHotWord = hotWordList[0][0] #defaultHotWord 被设置为列表中的第一个热门词汇。
    if request.args.get('hotWord'):defaultHotWord = request.args.get('hotWord') #从 URL 查询参数中获取名为 hotword 的参数。如果 URL 中有 hotword 参数（例如，?hotword=example），则 request.args.get('hotWord') 会返回该参数的值。在这种情况下，defaultHotWord 会被更新为这个查询参数的值。
    hotWordLen = getHotWordLen(defaultHotWord)
    xData,yData = getHotWordPageCreateAtCharData(defaultHotWord)
    value = SnowNLP(defaultHotWord).sentiments
    if value == 0.5:
        sentences = '中性'
    elif value > 0.5:
        sentences = '正面'
    elif value < 0.5:
        sentences = '负面'

    comments = getCommentFilterData(defaultHotWord)
    return render_template('hotWord.html',
                           username=username,
                           hotWordList=hotWordList,
                           defaultHotWord=defaultHotWord,
                           hotWordLen=hotWordLen,
                           sentences=sentences,
                           xData=xData,
                           yData=yData,
                           comments=comments,
    )

@pb.route('/tableData')
def tableData():
    username = session.get('username')
    defaultFlag = False
    if request.args.get('flag'):defaultFlag = True
    tableData = getTableData(defaultFlag)
    return render_template('tableData.html',
                           username=username,
                           tableData=tableData,
                           defaultFlag=defaultFlag
    )